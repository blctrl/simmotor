/* strtok_r prototype */
#ifdef __cplusplus
extern "C"
{
#endif
char* strtok_r(char *, const char *, char **);
#ifdef __cplusplus
}
#endif
