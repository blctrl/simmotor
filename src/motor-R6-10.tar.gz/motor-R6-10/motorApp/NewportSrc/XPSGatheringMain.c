void xps_gathering();

int main(int arvgc, char **argv) {
   xps_gathering();
   return(0);
}

