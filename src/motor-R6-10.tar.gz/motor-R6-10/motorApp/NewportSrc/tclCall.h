#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

epicsShareFunc void tclcall(char const *name,char const *taskName,char const *args);

#ifdef __cplusplus
}
#endif  /* __cplusplus */

