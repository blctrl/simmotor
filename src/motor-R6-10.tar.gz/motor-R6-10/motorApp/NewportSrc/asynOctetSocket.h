int ReadXPSSocket (int SocketIndex, char valueRtrn[], int returnSize, double timeout);
