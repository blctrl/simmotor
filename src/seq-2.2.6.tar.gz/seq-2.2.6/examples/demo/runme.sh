#!/bin/sh
./O.linux-x86/demo demo.stcmd
