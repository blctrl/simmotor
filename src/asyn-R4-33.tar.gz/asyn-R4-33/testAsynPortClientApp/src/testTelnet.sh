../../bin/linux-x86_64/testAsynIPPortClient localhost:20129 "help" "\r"
